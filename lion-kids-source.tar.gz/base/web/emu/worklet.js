// SPDX-License-Identifier: MPL-2.0
// Copyright (C) 2026 Charles Vestal
// An fm1-base app in an AudioWorklet: app.wasm is the whole FM-1 app (web/emu/emu_web.c). Each render
// quantum asks it for 128 frames, which runs the device's clock forward; between quanta the page's
// input goes in and, about 30 times a second, the screen, the lights, any saved objects and what the
// firmware said to a screen reader (fm1-reader's SysEx frames) go out.
// An app can add its own part (APP_DIR/web/emu/app_worklet.js, loaded first): globalThis.fm1App with any of
// load(fm1), message(fm1, m) for the page's { type: "app" } messages, process(fm1) before each quantum, and env:
// functions app.wasm imports (its "env" imports; any other is a stub that returns 0).

/** the dim controls' opacity for the dim layer's pulse of ns (APP_DIM_LEVELS, plat_dim_ns): 0.25 at 500 ns up to 1 at
 *  4,000 (a plain linear step: the page's view of the levels, not a measure of the light) */
function dimOpacity(ns) {
  const t = Math.min(4000, Math.max(500, ns));
  return +(0.25 + 0.75 * (t - 500) / 3500).toFixed(3);
}

const clock = globalThis.performance ? () => globalThis.performance.now() : () => Date.now();

class Fm1 extends AudioWorkletProcessor {
  constructor() {
    super();
    this.ex = null;
    this.input = null;
    this.sentBlits = -1;
    this.sentWrites = -1;
    this.lastFrame = 0;
    this.busy = 0;
    this.frames = 0;
    this.log = [];                                    // the session: [device ms, kind, value] (the page's "Copy session")
    this.port.onmessage = (e) => this.onMessage(e.data);
  }

  async onMessage(m) {
    if (m.type === "load") {
      const now = () => BigInt(Math.round(currentTime * 1e9));
      const wasi = {
        clock_time_get: (id, prec, out) => {
          new DataView(this.mem.buffer).setBigUint64(out, now(), true);
          return 0;
        },
        fd_write: (fd, iov, n, out) => { new DataView(this.mem.buffer).setUint32(out, 0, true); return 0; },
        proc_exit: () => {},
      };
      const stub = new Proxy(wasi, { get: (t, k) => (k in t ? t[k] : () => 0) });
      const appEnv = (globalThis.fm1App && globalThis.fm1App.env) || {};
      const env = new Proxy(appEnv, { get: (t, k) => (k in t ? t[k] : () => 0) });
      const { instance } = await WebAssembly.instantiate(m.wasm, { wasi_snapshot_preview1: stub, env });
      this.ex = instance.exports;
      this.mem = this.ex.memory;
      if (this.ex._initialize) this.ex._initialize();
      this.app = globalThis.fm1App || {};
      if (this.app.load) this.app.load(this);
      const max = this.ex.web_store_max();
      for (const [obj, bytes] of Object.entries(m.store || {})) {
        const b = new Uint8Array(bytes).subarray(0, max);
        new Uint8Array(this.mem.buffer, this.ex.web_store(+obj), b.length).set(b);
        this.ex.web_store_set_len(+obj, b.length);
      }
      this.sentWrites = this.ex.web_store_writes();
      this.ex.web_master(m.master ?? 2800);
      this.ex.web_boot();
      this.port.postMessage({ type: "ready" });
    } else if (!this.ex) {
      return;
    } else if (m.type === "buttons") {
      this.rec("b", m.mask >>> 0);
      this.ex.web_buttons(m.mask >>> 0);
    } else if (m.type === "keys") {
      this.rec("k", m.mask >>> 0);
      this.ex.web_keys(m.mask >>> 0);
    } else if (m.type === "enc") {
      this.rec("e", [m.role, m.n | 0]);
      this.ex.web_enc(m.role, m.n | 0);
    } else if (m.type === "master") {
      this.rec("m", m.value | 0);
      this.ex.web_master(m.value | 0);
    } else if (m.type === "log") {                    // the session so far, for the page to turn into a script
      this.port.postMessage({ type: "log", log: this.log, now: this.ex.web_now() >>> 0 });
    } else if (m.type === "sysex") {                  // a screen reader's frame: the bytes between F0 and F7
      const b = Uint8Array.from(m.bytes).subarray(0, 64);
      new Uint8Array(this.mem.buffer, this.ex.web_sysex_buf(), b.length).set(b);
      this.ex.web_sysex(b.length);
    } else if (m.type === "app" && this.app.message) {
      this.app.message(this, m);
    }
  }

  rec(kind, v) {
    if (this.log.length < 200000) this.log.push([this.ex.web_now() >>> 0, kind, v]);
  }

  publish() {
    const ex = this.ex;
    const blits = ex.web_blits();
    const msg = { type: "frame", buttons: ex.web_lit_buttons() >>> 0, keys: ex.web_lit_keys() >>> 0,
                  dimButtons: ex.web_dim_buttons() >>> 0, dimKeys: ex.web_dim_keys() >>> 0 };
    if (ex.web_dim_ns) msg.dimOp = dimOpacity(ex.web_dim_ns() >>> 0);   // only an app with APP_DIM_LEVELS
    if (this.frames >= 44100) {                       // the share of real time spent running the device
      msg.load = Math.round(100 * this.busy / (this.frames / 44.1));
      this.rec("l", msg.load);
      this.busy = this.frames = 0;
    }
    const transfer = [];
    const said = ex.web_said_len();
    if (said) {                                       // whole F0..F7 frames
      msg.said = new Uint8Array(this.mem.buffer, ex.web_said_buf(), said).slice();
      ex.web_said_clear();
      transfer.push(msg.said.buffer);
    }
    if (blits !== this.sentBlits) {
      this.sentBlits = blits;
      msg.fb = new Uint16Array(this.mem.buffer, ex.web_fb(), 240 * 240).slice();
      transfer.push(msg.fb.buffer);
    }
    const writes = ex.web_store_writes();
    if (writes !== this.sentWrites) {
      this.sentWrites = writes;
      msg.store = {};
      for (let o = 0; o < ex.web_nobj(); o++) {
        const n = ex.web_store_len(o);
        if (n >= 0) msg.store[o] = new Uint8Array(this.mem.buffer, ex.web_store(o), n).slice();
      }
    }
    this.port.postMessage(msg, transfer);
  }

  process(inputs, outputs) {
    if (!this.ex) return true;
    const out = outputs[0];
    const n = out[0].length;
    const t0 = clock();
    if (this.app.process) this.app.process(this);
    this.ex.web_render(n);
    this.busy += clock() - t0;
    this.frames += n;
    out[0].set(new Float32Array(this.mem.buffer, this.ex.web_out_l(), n));
    if (out[1]) out[1].set(new Float32Array(this.mem.buffer, this.ex.web_out_r(), n));
    if (currentTime - this.lastFrame >= 1 / 30) {
      this.lastFrame = currentTime;
      this.publish();
    }
    return true;
  }
}

registerProcessor("fm1", Fm1);
