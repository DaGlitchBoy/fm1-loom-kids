#!/usr/bin/env python3
# SPDX-License-Identifier: MPL-2.0
"""LOOM-8's factory samples: 9W9's 909 drums (app/samples/909_*, tools/prep_909.py) and a noise sweep made here
(mono at 22050 Hz); the
recorded instruments (app/samples/, tools/prep_recordings.py: VSCO 2 CE, CC0); a vinyl loop made here; the four
breaks' places (app/samples/: the slice engine's), empty: since 0.7 they are a pack for the user bank (the samples page
installs them; the firmware finds them there by name, dsp/sample.c). Each at its own rate, IMA ADPCM with a checkpoint every 64
samples (tools/sampleio.py), into a header the firmware compiles in (dsp/sample.c). Deterministic: the same bytes every run.

  gen_samples.py OUT.h [WAVDIR]      WAVDIR: also each sample as a 16-bit WAV (to listen to)
  gen_samples.py --break-specs       the break pack as tools/loom_samples.py specs, one a line
  gen_samples.py --factory-bank OUT.bin   the factory set as a user bank's image, its entries marked as the factory
                                     set's (the installer and the samples page add them to the FM-1's bank)

Since 0.8 the LOOM-8 FM-1 build reads these sounds from the flash sample bank.
The LION KIDS FM-1 build embeds the instruments and breaks, without using its song storage.
"""
import math
import struct
import sys
import wave
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import sampleio as sio  # noqa: E402

SR = sio.RATE
TWO_PI = 2.0 * math.pi


class Rng:
    """a small LCG: the same noise everywhere"""
    def __init__(self, seed):
        self.s = seed & 0xFFFFFFFF

    def __call__(self):
        self.s = (self.s * 1664525 + 1013904223) & 0xFFFFFFFF
        return (self.s / 2147483648.0) - 1.0


def secs(t):
    return int(round(t * SR))


def onepole(x, hz, hp=False):
    a = 1.0 - math.exp(-TWO_PI * hz / SR)
    y, out = 0.0, []
    for v in x:
        y += a * (v - y)
        out.append(v - y if hp else y)
    return out


def bandpass(x, hz_of, q):
    """a state-variable band-pass whose centre may move (hz_of: index -> Hz)"""
    lo = bp = 0.0
    out = []
    for i, v in enumerate(x):
        f = 2.0 * math.sin(math.pi * min(hz_of(i), SR * 0.24) / SR)
        hp = v - lo - bp / q
        bp += f * hp
        lo += f * bp
        out.append(bp)
    return out


def vinyl():
    """a record's run-out: crackle (sparse clicks, each a few samples, bright and dull) over a low hiss and a little
    rumble, a second that loops (each click whole inside it)"""
    n, r = secs(1.0), Rng(8)
    hiss = onepole(onepole([r() for _ in range(n)], 3500.0), 3500.0)
    rumble = onepole(onepole([r() for _ in range(n)], 60.0), 60.0)
    out = [0.25 * h + 1.5 * u for h, u in zip(hiss, rumble)]
    i = secs(0.004)
    while i < n - secs(0.004):
        a, tau = r() * (1.0 if r() > -0.6 else 3.0), (0.00015 if r() > -0.3 else 0.0006)
        for k in range(secs(0.004)):
            out[i + k] += a * math.exp(-(k / SR) / tau)
        i += int(secs(0.012) + (r() + 1.0) * secs(0.045))
    return out, (0, n), 60


def sweep():
    """noise through a resonant band-pass rising from 200 Hz to 8 kHz, swelling in and falling away"""
    n, r = secs(0.60), Rng(7)
    x = [r() for _ in range(n)]
    y = bandpass(x, lambda i: 200.0 * math.pow(40.0, i / n), 6.0)
    return [v * math.sin(math.pi * i / n) ** 0.7 for i, v in enumerate(y)]


BREAK_ROOT = 53                                      # F3, the lowest key: slice 1



# the drums first (their places in the bank as the made ones had: projects name samples by number): renders of 9W9
# by athousanddetails, the TR-909 model (GPL-3.0), cut where they fall silent (tools/prep_909.py); the kick, snare and
# clap MPL-2.0 by his permission, the hat (ER-99's sample) GPL-3.0, in the bank and the emulator only, never the
# firmware image (LICENSING.md): name, file, rate
DRUMS = [("kick", "909_kick.wav", 16000), ("snare", "909_snare.wav", 22050), ("hat", "909_hat.wav", 22050),
         ("clap", "909_clap.wav", 22050)]
SAMPLES = [("sweep", sweep)]
# recorded instruments (app/samples/, tools/prep_recordings.py: from VSCO 2 CE, CC0), after the made drums: name, file,
# rate the bank keeps it at, root; a sustained one's loop comes from its file ('smpl')
INSTRUMENTS = [("piano", "piano.wav", 16000, 60), ("upright", "upright.wav", 11025, 28),
               ("strings", "strings.wav", 16000, 60), ("brass", "brass.wav", 16000, 62),
               ("flute", "flute.wav", 16000, 72), ("orch hit", "orch_hit.wav", 16000, 60)]
MADE_AFTER = [("vinyl", vinyl, 11025)]               # made here, after the instruments, at their own rate
# recordings (app/samples/: one bar each as labelled, mono, cut from the source loops), after the made ones: name,
# file, rate the user bank keeps it at, bars. Not in the image since 0.7 (94 KB): their places stay (projects name
# samples by number) as empty rows, filled from the user bank by name when the break pack is installed (the samples
# page's "Add the breaks", tools/loom_samples.py breaks) (a break: the slice engine plays it at the song's tempo, slice 1 on
# BREAK_ROOT; choke is labelled 69 BPM but is a half-time beat at 138, so its cut holds two bars). The breaks:
# free loops posted on Reddit by u/FCTRYBEATS, their words "You have my full permission to use these loops in commercial
# or personal projects" (LICENSING.md has the source)
RECORDINGS = [("classic", "classic.wav", 16000, 1), ("heat", "heat.wav", 16000, 1), ("choke", "choke.wav", 16000, 2),
              ("ecstasy", "ecstasy.wav", 16000, 1)]
BUDGET = 100 * 1024                                  # B: the image's room for the factory bank
SAMPLE_DIR = Path(__file__).resolve().parents[1] / "app" / "samples"


def names():
    """the factory bank's names, in its order"""
    return ([d[0] for d in DRUMS] + [n for n, _ in SAMPLES] + [i[0] for i in INSTRUMENTS] + [m[0] for m in MADE_AFTER] +
            [r[0] for r in RECORDINGS])


def made(name, fn, rate):
    v = fn()
    loop, root, bars = None, 60, 0
    if isinstance(v, tuple):
        v, loop, root, *more = v
        bars = more[0] if more else 0
    if rate != SR:
        v = sio.resample(v, SR, rate)
        loop = loop and (loop[0] * rate // SR, min(len(v), loop[1] * rate // SR))
    return (name, sio.to_int16(v), root, loop, bars, rate)


def build():
    out = []
    for name, f, rate in DRUMS:
        sr, x, _ = sio.read_any_wav(SAMPLE_DIR / f)
        out.append((name, sio.to_int16(sio.emphasis(sio.resample(x, sr, rate) if sr != rate else x)), 60, None, 0,
                    rate))
    out += [made(name, fn, SR) for name, fn in SAMPLES]
    for name, f, rate, root in INSTRUMENTS:
        sr, x, loop = sio.read_any_wav(SAMPLE_DIR / f)
        if sr != rate:
            x = sio.resample(x, sr, rate)
            loop = loop and (loop[0] * rate // sr, loop[1] * rate // sr)
        out.append((name, sio.to_int16(sio.emphasis(x)), root, loop and (loop[0], loop[1] + 1), 0, rate))
    out += [made(name, fn, rate) for name, fn, rate in MADE_AFTER]
    return out


def breaks():
    """the break pack's samples, as build()'s rows (for the emulator's build, which keeps them built in)"""
    out = []
    for name, f, rate, bars in RECORDINGS:
        sr, x, _ = sio.read_any_wav(SAMPLE_DIR / f)
        out.append((name, sio.to_int16(sio.emphasis(sio.resample(x, sr, rate))), BREAK_ROOT, None, bars, rate))
    return out


def break_specs():
    """the break pack as tools/loom_samples.py specs: NAME=file.wav:ROOT@BARS%RATE"""
    return [f"{name}={SAMPLE_DIR / f}:{BREAK_ROOT}@{bars}%{rate}" for name, f, rate, bars in RECORDINGS]


def factory_set():
    """the factory set (the image's samples until 0.8) as sampleio.user_bank's samples, marked as the factory set's"""
    return [(name, s, root, loop, bars, rate, sio.E_FACTORY) for name, s, root, loop, bars, rate in build()]


def main():
    if len(sys.argv) == 2 and sys.argv[1] == "--break-specs":     # for the tests and loom_samples.py
        print("\n".join(break_specs()))
        return
    if len(sys.argv) == 3 and sys.argv[1] == "--factory-bank":
        img = sio.user_bank(factory_set())
        Path(sys.argv[2]).parent.mkdir(parents=True, exist_ok=True)
        Path(sys.argv[2]).write_bytes(img)
        print(f"factory bank: {len(factory_set())} samples, {sio.bank_used(img)} B")
        return
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    smp = build()
    adp_all, ck_all, rows = bytearray(), [], []
    for name, s, root, loop, bars, rate in smp:
        adp, ck = sio.ima_encode(s)
        ls, le = loop if loop else (0, 0)
        rows.append((name, len(adp_all), len(ck_all), len(s), ls, le, root, bars, rate))
        adp_all += adp
        ck_all += ck
    for name, _, rate, bars in RECORDINGS:          # the breaks' places: empty (n 0), found in the user bank by name
        rows.append((name, 0, 0, 0, 0, 0, BREAK_ROOT, bars, rate))
    total = len(adp_all) + 4 * len(ck_all)
    if total > BUDGET:
        sys.exit(f"gen_samples: {total} B, over the {BUDGET // 1024} KB the factory bank may take (the image's room)")
    lines = ["/* generated by tools/gen_samples.py: LOOM-8's factory samples (made procedurally, then recordings; the",
             f" * breaks' rows empty: n 0, the user bank's), IMA ADPCM each at its rate, a checkpoint every {sio.BLK} samples; {len(adp_all)} B of ADPCM + "
             f"{4 * len(ck_all)} B of checkpoints */",
             "#pragma once",
             f"#define SMP_NFACT {len(rows)}",
             f"#define SMP_FACT_NSET {len(smp)}   /* the factory set (the rows before the breaks): the bank's entries "
             "of it on the FM-1 */",
             f"#define SMP_FACT_BREAK {[r[0] for r in rows].index(RECORDINGS[0][0])}   /* the first break: the slice "
             "engine's sample */",
             "#if SMP_FACT_BUILTIN                /* (dsp/sample.c: the host and the emulator) */",
             f"static const uint8_t SMP_FACT_ADP[{len(adp_all)}] = {{"]
    for i in range(0, len(adp_all), 24):
        lines.append("    " + ", ".join(str(b) for b in adp_all[i:i + 24]) + ",")
    lines.append("};")
    lines.append(f"static const uint32_t SMP_FACT_CK[{len(ck_all)}] = {{")
    for i in range(0, len(ck_all), 8):
        lines.append("    " + ", ".join(f"0x{c:08X}u" for c in ck_all[i:i + 8]) + ",")
    lines.append("};")
    lines.append("#endif")
    lines.append("/* name, ADPCM offset, checkpoint index, samples, loop start, loop end (0: none), root, bars (0: "
                 "not a loop of bars), rate */")
    lines.append("static const struct { const char *name; uint32_t adp, ck, n, ls, le; uint8_t root, bars; "
                 "uint16_t rate; } SMP_FACT[SMP_NFACT] = {")
    for name, a, c, n, ls, le, root, bars, rate in rows:
        lines.append(f'    {{"{name}", {a}u, {c}u, {n}u, {ls}u, {le}u, {root}, {bars}, {rate}}},')
    lines.append("};")
    # the emulator (PLAT_WEB, no flash to fit) keeps the breaks built in, as if the pack were installed
    wadp, wck, wrows = bytearray(), [], []
    for name, s, root, loop, bars, rate in breaks():
        adp, ck = sio.ima_encode(s)
        wrows.append((len(wadp), len(wck), len(s)))
        wadp += adp
        wck += ck
    lines.append("#if defined(PLAT_WEB) || defined(LION_KIDS_DEVICE)")
    lines.append(f"static const uint8_t SMP_WEB_ADP[{len(wadp)}] = {{")
    for i in range(0, len(wadp), 24):
        lines.append("    " + ", ".join(str(b) for b in wadp[i:i + 24]) + ",")
    lines.append("};")
    lines.append(f"static const uint32_t SMP_WEB_CK[{len(wck)}] = {{")
    for i in range(0, len(wck), 8):
        lines.append("    " + ", ".join(f"0x{c:08X}u" for c in wck[i:i + 8]) + ",")
    lines.append("};")
    lines.append("/* the breaks in the factory rows' order (from SMP_FACT_BREAK): ADPCM offset, checkpoint index, samples */")
    lines.append(f"static const uint32_t SMP_WEB[{len(wrows)}][3] = {{")
    for a, c, n in wrows:
        lines.append(f"    {{{a}u, {c}u, {n}u}},")
    lines.append("};")
    lines.append("#endif")
    Path(sys.argv[1]).parent.mkdir(parents=True, exist_ok=True)
    Path(sys.argv[1]).write_text("\n".join(lines) + "\n")
    if len(sys.argv) > 2:
        d = Path(sys.argv[2])
        d.mkdir(parents=True, exist_ok=True)
        for name, s, root, loop, bars, rate in smp:
            with wave.open(str(d / f"{name}.wav"), "wb") as w:
                w.setnchannels(1)
                w.setsampwidth(2)
                w.setframerate(rate)
                w.writeframes(struct.pack("<%dh" % len(s), *s))
    print(f"samples: {len(rows)}, {total} B")


if __name__ == "__main__":
    main()
